import mongoose from "mongoose";

export interface IRoom {
    id: mongoose.Types.ObjectId;
    number_room: string;
    type: string;
    guest_capacity: number;
    daily_rate: string;
    photo: string;
    status: string;
}

export interface IRoomDTO {
    id: mongoose.Types.ObjectId;
    number_room: string;
    type: string;
    guest_capacity: number;
    daily_rate: string;
    photo: string;
    status: string;
}
