import { Request, Response, NextFunction } from "express";
import jwt from 'jsonwebtoken';
import { IAdmin } from "../entities/Admin";

interface AuthenticatedRequest extends Request {
    admin?: IAdmin;
}

export const authenticateAdminJWT = (request: AuthenticatedRequest, response: Response, next: NextFunction) => {
    const token = request.header('Authorization')?.split(' ')[1];

    if (!token) {
        return response.status(401).json({ message: 'Token not provided' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as any;

        if (decoded.role !== 'admin') {
            return response.status(403).json({ message: 'Forbidden: Not an admin' });
        }

        request.admin = decoded;
        next();
    } catch (error) {
        response.status(401).json({ message: 'Invalid token' });
    }
};
