// src/repositories/AdminRepository.ts
const AdminModel = require('../models/AdminModel');
import { IAdmin } from '../entities/Admin';

class AdminRepository {
  async findByEmail(email: string): Promise<IAdmin | null> {
    return AdminModel.findOne({ email });
  }
}

export default new AdminRepository();
