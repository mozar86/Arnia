// src/services/AdminService.ts
import AdminRepository from '../repositories/AdminRepository';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Document } from 'mongoose';
import { IAdmin } from '../entities/Admin';

interface IAdminDocument extends IAdmin, Document {
  password: string;
  _id: string; // Mongoose fornece _id por padrão
}

class AdminService {
  async login(email: string, password: string): Promise<{ token: string } | null> {
    const admin = await AdminRepository.findByEmail(email) as IAdminDocument | null;
    if (!admin) {
      return null;
    }

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      return null;
    }

    const token = jwt.sign({ id: admin._id, role: 'admin' }, process.env.JWT_SECRET as string, {
      expiresIn: '1h',
    });

    return { token };
  }
}

export default new AdminService();
