import 'dotenv/config';

export const databaseConfig = {
    uri: process.env.DATABASE_URL as string
  };