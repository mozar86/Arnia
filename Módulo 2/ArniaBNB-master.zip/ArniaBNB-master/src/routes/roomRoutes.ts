import { Router } from "express";
import { createRoom, updateRoomController, listAvailableRooms, listAvailableRoomsByDate } from "../controllers/roomController";
import { authenticateAdminJWT } from "../middlewares/authAdmin";
import { verifyRoomExists } from "../middlewares/verifyRoom";
import validate from "../middlewares/validate";
import * as roomSchema from '../schemas/room';

const router = Router();

router.post("/room", authenticateAdminJWT, validate(roomSchema.RoomCreate.schema), createRoom);
router.patch("rooms/:id", authenticateAdminJWT, verifyRoomExists, updateRoomController);
router.get("/rooms/available", listAvailableRooms);
router.get("/rooms/available-by-date", listAvailableRoomsByDate);

export default router;
