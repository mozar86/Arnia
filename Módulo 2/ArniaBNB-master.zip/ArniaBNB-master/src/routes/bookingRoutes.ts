import { Router } from "express";
import { createBooking, cancelBooking, listBookingsByGuest } from "../controllers/bookingController";
import { authenticateAdminJWT } from "../middlewares/authAdmin";
import { authenticateGuestJWT } from "../middlewares/authGuest";

const router = Router();

router.post("/bookings", authenticateAdminJWT, createBooking);
router.patch("/bookings/:id/cancel", authenticateAdminJWT, cancelBooking);
router.get("/bookings", authenticateGuestJWT, listBookingsByGuest);

export default router;
